package com.example.crud;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;

public class HelloController{

    @FXML
    private Label DokterTujuan;

    @FXML
    private Label Id;

    @FXML
    private Label Keluhan;

    @FXML
    private Label Nama;

    @FXML
    private Label Usia;

    @FXML
    private Button btnHapus;

    @FXML
    private Button btnReset;

    @FXML
    private Button btnTambah;

    @FXML
    private Button btnUbah;

    @FXML
    private TableColumn<ModelData, String> colDokter;

    @FXML
    private TableColumn<ModelData, String> colId;

    @FXML
    private TableColumn<ModelData, String> colKeluhan;

    @FXML
    private TableColumn<ModelData, String> colNama;

    @FXML
    private TableColumn<ModelData, String> colUsia;

    @FXML
    private TableView<ModelData> tableData;

    @FXML
    private TextField txtDokterTujuan;

    @FXML
    private TextField txtId;

    @FXML
    private TextField txtKeluhan;

    @FXML
    private TextField txtNama;

    @FXML
    private TextField txtUsia;

    // ObservableList untuk menyimpan data pasien
    private ObservableList<ModelData> dataList;

    public HelloController() {
        // Menginisialisasi ObservableList
        dataList = FXCollections.observableArrayList();
    }

    @FXML
    public void initialize() {
        // Mengikat data ke kolom di TableView
        colNama.setCellValueFactory(cellData -> cellData.getValue().namaProperty());
        colId.setCellValueFactory(cellData -> cellData.getValue().idProperty());
        colUsia.setCellValueFactory(cellData -> cellData.getValue().usiaProperty());
        colKeluhan.setCellValueFactory(cellData -> cellData.getValue().keluhanProperty());
        colDokter.setCellValueFactory(cellData -> cellData.getValue().dokterTujuanProperty());

        // Menghubungkan TableView dengan ObservableList
        tableData.setItems(dataList);
    }

    // Method untuk menangani tombol Tambah
    @FXML
    void handleTambah(ActionEvent event) {
        if (isInputValid()) {
            // Menambahkan data baru ke dalam ObservableList
            ModelData newData = new ModelData(
                    txtId.getText(),
                    txtNama.getText(),
                    txtUsia.getText(),
                    txtKeluhan.getText(),
                    txtDokterTujuan.getText()
            );

            // Menambahkan data baru ke dalam ObservableList
            dataList.add(newData);

            // Menampilkan pesan di terminal (bisa dihapus nantinya)
            System.out.println("Tambah button clicked!");
            System.out.println("Nama: " + newData.getNama());  // Sekarang bisa menggunakan getName()
            System.out.println("ID: " + newData.getId());
            System.out.println("Usia: " + newData.getUsia());
            System.out.println("Keluhan: " + newData.getKeluhan());
            System.out.println("Dokter Tujuan: " + newData.getDokterTujuan());
        } else {
            System.out.println("Input tidak valid.");
        }
    }

    // Method untuk menangani tombol Hapus
    @FXML
    void handleHapus(ActionEvent event) {
        // Mendapatkan item yang terpilih pada TableView
        ModelData selectedPatient = tableData.getSelectionModel().getSelectedItem();
        if (selectedPatient != null) {
            // Menghapus data dari ObservableList
            dataList.remove(selectedPatient);
            System.out.println("Data telah dihapus.");
        } else {
            System.out.println("Pilih data terlebih dahulu untuk dihapus.");
        }
    }

    // Method untuk menangani tombol Reset
    @FXML
    void handleReset(ActionEvent event) {
        txtId.clear();
        txtNama.clear();
        txtUsia.clear();
        txtKeluhan.clear();
        txtDokterTujuan.clear();
        System.out.println("Reset button clicked!");
    }

    // Method untuk menangani tombol Ubah
    @FXML
    void handleUbah(ActionEvent event) {
        // Mendapatkan item yang terpilih pada TableView
        ModelData selectedPatient = tableData.getSelectionModel().getSelectedItem();
        if (selectedPatient != null && isInputValid()) {
            // Memperbarui data
            selectedPatient.setId(txtId.getText());
            selectedPatient.setNama(txtNama.getText());
            selectedPatient.setUsia(txtUsia.getText());
            selectedPatient.setKeluhan(txtKeluhan.getText());
            selectedPatient.setDokterTujuan(txtDokterTujuan.getText());

            // Menyegarkan TableView
            tableData.refresh();
            System.out.println("Data telah diubah.");
        } else {
            System.out.println("Pilih data terlebih dahulu untuk diubah.");
        }
    }

    // Method untuk validasi input
    private boolean isInputValid() {
        if (txtId.getText().isEmpty() ||
                txtNama.getText().isEmpty() ||
                txtUsia.getText().isEmpty() ||
                txtKeluhan.getText().isEmpty() ||
                txtDokterTujuan.getText().isEmpty()) {
            System.out.println("Semua field harus diisi.");
            return false;
        }
        if (!txtId.getText().matches("\\d+")) {
            System.out.println("ID harus berupa angka.");
            return false;
        }
        return true;
    }
}
