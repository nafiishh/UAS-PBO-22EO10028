package com.example.crud;

import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

public class ModelData {

    private final StringProperty id;
    private final StringProperty nama;
    private final StringProperty usia;
    private final StringProperty keluhan;
    private final StringProperty dokterTujuan;

    // Constructor dengan argumen
    public ModelData(String id, String nama, String usia, String keluhan, String dokterTujuan) {
        this.id = new SimpleStringProperty(id);
        this.nama = new SimpleStringProperty(nama);
        this.usia = new SimpleStringProperty(usia);
        this.keluhan = new SimpleStringProperty(keluhan);
        this.dokterTujuan = new SimpleStringProperty(dokterTujuan);
    }

    // Constructor tanpa argumen (untuk beberapa kasus seperti binding kosong)
    public ModelData() {
        this.id = new SimpleStringProperty("");
        this.nama = new SimpleStringProperty("");
        this.usia = new SimpleStringProperty("");
        this.keluhan = new SimpleStringProperty("");
        this.dokterTujuan = new SimpleStringProperty("");
    }

    // Getter dan Setter untuk properti id
    public String getId() {
        return id.get();  // Menggunakan get() pada StringProperty
    }

    public void setId(String id) {
        this.id.set(id);
    }

    public StringProperty idProperty() {
        return id;
    }

    // Getter dan Setter untuk properti nama
    public String getNama() {
        return nama.get();  // Menggunakan get() pada StringProperty
    }

    public void setNama(String nama) {
        this.nama.set(nama);
    }

    public StringProperty namaProperty() {
        return nama;
    }

    // Getter dan Setter untuk properti usia
    public String getUsia() {
        return usia.get();  // Menggunakan get() pada StringProperty
    }

    public void setUsia(String usia) {
        this.usia.set(usia);
    }

    public StringProperty usiaProperty() {
        return usia;
    }

    // Getter dan Setter untuk properti keluhan
    public String getKeluhan() {
        return keluhan.get();  // Menggunakan get() pada StringProperty
    }

    public void setKeluhan(String keluhan) {
        this.keluhan.set(keluhan);
    }

    public StringProperty keluhanProperty() {
        return keluhan;
    }

    // Getter dan Setter untuk properti dokterTujuan
    public String getDokterTujuan() {
        return dokterTujuan.get();  // Menggunakan get() pada StringProperty
    }

    public void setDokterTujuan(String dokterTujuan) {
        this.dokterTujuan.set(dokterTujuan);
    }

    public StringProperty dokterTujuanProperty() {
        return dokterTujuan;
    }
}
